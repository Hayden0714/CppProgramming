void displayArray(int* arr, int size){
  cout << endl;

  for(int k = 0; k < size; k++){
    cout << arr[k] << " ";
  }

  cout << endl;
}