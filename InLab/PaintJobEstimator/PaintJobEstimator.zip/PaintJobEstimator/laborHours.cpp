
double laborHours(double wallArea){

  double hours = wallArea / WALL_AREA_PER_GALLON;

  return hours;
}