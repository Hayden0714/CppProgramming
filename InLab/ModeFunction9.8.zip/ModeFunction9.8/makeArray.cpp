//make array function

int* makeArray(int size){
  int* ptr = new int[size];

  return ptr;
}